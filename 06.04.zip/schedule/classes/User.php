<?php


class User extends Table
{
    public function validate()
    {
        return false;
    }
}