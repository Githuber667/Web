<?php


class Gruppa extends Table
{
    public function validate()
    {
        return false;
    }
}