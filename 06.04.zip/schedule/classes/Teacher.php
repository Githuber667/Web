<?php


class Teacher extends Table
{
    public function validate()
    {
        return false;
    }
}