<?php


class Subject extends Table
{
    public function validate()
    {
        return false;
    }
}