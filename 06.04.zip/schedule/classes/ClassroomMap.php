<?php


class ClassroomMap extends BaseMap
{
    public $classroom_id= 0;
    public $name='';
    public $active= 1;

}