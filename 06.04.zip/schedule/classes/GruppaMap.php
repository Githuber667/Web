<?php


class GruppaMap extends BaseMap
{
    public $gruppa_id=0;
    public $name='';
    public $special_id=0;
    public $date_begin='';
    public $date_end='';
}