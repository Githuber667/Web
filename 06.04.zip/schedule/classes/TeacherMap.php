<?php


class TeacherMap extends BaseMap
{
    public $user_id=0;
    public $otdel_id=0;
}