<?php


class LessonPlanMap extends BaseMap
{
    public $lesson_plan_id=0;
    public $gruppa_id=0;
    public  $subject_id=0;
    public $user_id=0;

}