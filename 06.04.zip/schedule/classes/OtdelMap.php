<?php


class OtdelMap extends BaseMap
{
    public $otdel_id = 0;
    public $name = '';
    public $active = 1;
}