<?php


class LessonPlan extends Table
{
    public function validate()
    {
        return false;
    }
}