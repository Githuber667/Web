<?php


class Otdel extends Table
{
    public function validate()
    {
        return false;
    }
}