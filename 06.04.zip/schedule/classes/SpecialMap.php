<?php


class SpecialMap extends BaseMap
{
    public $special_id=0;
    public $name='';
    public $otdel_id=0;
    public $active=0;
}