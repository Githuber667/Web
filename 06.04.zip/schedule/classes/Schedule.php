<?php


class Schedule extends Table
{
    public function validate()
    {
        return false;
    }
}