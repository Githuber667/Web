<?php


class Special extends Table
{
    public function validate()
    {
        return false;
    }
}