<?php


class Classroom extends Table
{
    public function validate()
    {
        return false;
    }
}