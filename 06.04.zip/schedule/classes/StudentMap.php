<?php


class StudentMap extends BaseMap
{
    public $user_id=0;
    public $gruppa_id=0;
    public $num_zach='';
}