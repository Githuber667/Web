<?php


class Student extends Table
{
    public function validate()
    {
        return false;
    }
}