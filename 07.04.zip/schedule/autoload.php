<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of autoload
 *
 * @author User
 */
spl_autoload_register(function ($class_name) {
include 'classes/'.$class_name . '.php';
});
